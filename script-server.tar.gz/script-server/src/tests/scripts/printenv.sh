#!/bin/bash
# this is a wrapper around printenv to ignore any parameters
printenv