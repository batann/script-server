#!/usr/bin/env python
import sys

print
'hello, your words are:'
for word in sys.argv:
    print '- ' + word
