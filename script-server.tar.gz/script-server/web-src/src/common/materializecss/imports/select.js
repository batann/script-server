// DO NOT TOUCH ORDER
import './global'

import 'materialize-css/js/select';
import 'materialize-css/sass/components/forms/_forms.scss';
import './dropdown'
import '@/assets/css/materializecss/material-select.css';