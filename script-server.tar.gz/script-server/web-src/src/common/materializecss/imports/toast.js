// DO NOT TOUCH ORDER
import './global'

import 'materialize-css/js/toasts';
import 'materialize-css/sass/components/_toast.scss';