// DO NOT TOUCH ORDER
import './global'

import 'materialize-css/js/cards';
import 'materialize-css/sass/components/_cards.scss';
import '@/assets/css/materializecss/material-cards.css'