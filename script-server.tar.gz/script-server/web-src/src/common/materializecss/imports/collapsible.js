// DO NOT TOUCH ORDER
import './global'

import 'materialize-css/js/collapsible';
import 'materialize-css/sass/components/_collapsible.scss';