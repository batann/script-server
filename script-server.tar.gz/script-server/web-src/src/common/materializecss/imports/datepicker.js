// DO NOT TOUCH ORDER
import './global'
import './modal'
import './select'

import 'materialize-css/js/datepicker';
import 'materialize-css/sass/components/_datepicker.scss';
import '@/assets/css/materializecss/material-datepicker.css'