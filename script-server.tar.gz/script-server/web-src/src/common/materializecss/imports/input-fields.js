// DO NOT TOUCH ORDER
import './global'

import 'materialize-css/js/forms';
import 'materialize-css/sass/components/forms/_forms.scss';