// DO NOT TOUCH ORDER
import './global'

import 'materialize-css/sass/components/_preloader.scss';