// DO NOT TOUCH ORDER
import './global'

import 'materialize-css/js/chips';
import 'materialize-css/sass/components/_chips.scss';
import '@/assets/css/materializecss/material-chips.css';