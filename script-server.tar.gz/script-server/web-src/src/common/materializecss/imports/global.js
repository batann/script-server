import 'materialize-css/js/cash';
import 'materialize-css/js/global';
import 'materialize-css/js/waves'
import Component from 'exports-loader?exports=default Component!materialize-css/js/component.js'

global.Component = Component;
