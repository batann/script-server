// DO NOT TOUCH ORDER
import './global'

import 'materialize-css/js/anime.min';
import 'materialize-css/js/dropdown';
import 'materialize-css/sass/components/_dropdown.scss';
import '@/assets/css/materializecss/material-dropdown.css';