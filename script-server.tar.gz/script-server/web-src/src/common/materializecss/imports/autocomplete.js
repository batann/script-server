// DO NOT TOUCH ORDER
import './global'
import './dropdown'

import 'materialize-css/js/autocomplete';