// DO NOT TOUCH ORDER
import './global'

import 'materialize-css/js/anime.min';
import 'materialize-css/js/tabs';
import 'materialize-css/sass/components/_tabs.scss';
import '@/assets/css/materializecss/material-tabs.css';