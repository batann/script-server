<template>
  <div>
    <router-view/>
  </div>
</template>

<script>

export default {
  name: 'ScriptConfigListPage',

  components: {}
}
</script>

<style scoped>

</style>